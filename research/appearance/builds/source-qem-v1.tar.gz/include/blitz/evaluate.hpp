#pragma once
#include "mesh.hpp"
#include <functional>
#include <limits>
namespace blitz {
enum class Profile:uint8_t { Coverage,Normals,Attributes };
struct Weights { double normal{180.0/(10*3.14159265358979323846)},color{4},material{4}; };
struct ViewSet { uint16_t orthographic{642},perspective{64}; uint32_t rotation_seed{0xB1172026}; };
// Optional first failing appearance sample. Costs are squared metric components;
// a missing compatible sample is not a bound on continuous appearance.
struct EvaluationWitness {
    uint32_t view{},x{},y{};
    uint8_t direction{},supersample{};
    double spatial{},normal{},color{},material{};
    bool present{},target_visible{};
};
struct PerformanceStats {
    uint64_t reduction_ns{},raster_ns{},distance_ns{},appearance_peak_bytes{};
    uint64_t solve_attempts{},singular_solves{},nonfinite_solves{},position_fallbacks{},nonfinite_costs{};
    uint64_t coverage_rasters{},coverage_fields{},coverage_mask_hits{},coverage_field_hits{},coverage_cache_bypasses{};
    uint32_t coverage_cache_peak_bytes{}; // Charged payload and entry capacities; at most 256 MiB.
};
struct EvalSettings {
    Profile profile{Profile::Normals}; Weights weights{}; ViewSet views{};
    uint8_t supersample{8},max_supersample{32};
    double screen_size{512},limit{2},max_changed_area{1.0};
    bool force_two_sided{false},force_scalar{false};
    std::function<bool()> cancelled;
    PerformanceStats* performance{}; // Borrowed optional accumulator; evaluate() adds to it.
    bool conservative_screen{}; // Coverage lower-bound rejection only; never a final audit.
    EvaluationWitness* witness{}; // Borrowed, reset by evaluate(); optional diagnostics.
};
struct Measurement {
    double error{},coverage{},coverage_upper{},changed_area{},normal_degrees{};
    uint32_t worst_view{},changed_area_worst_view{},views_evaluated{};
    uint8_t supersample{}; // Sampling of worst_view; the area-worst view may refine differently.
    bool complete{true},passed{true},resource_limited{};
};
struct Pixel {
    Vec3 normal{}; Vec4 color{};
    float depth{std::numeric_limits<float>::infinity()};
    uint16_t material{}; uint8_t covered{},visible{};
};
struct Raster { uint32_t width{},height{}; std::vector<Pixel> pixels; bool clipped{}; };
struct Camera { Vec3 right,up,forward; double distance{},focal{},scale{}; bool perspective{}; };
std::vector<Camera> cameras(const Bounds&,double,ViewSet);
Raster rasterize(MeshView,const Bounds&,const Camera&,double,uint8_t,bool);
double coverage_distance(const Raster&,const Raster&,uint8_t,bool force_scalar=false);
double attributed_distance(const Raster&,const Raster&,const EvalSettings&,double);
Measurement evaluate(MeshView,MeshView,const Bounds&,const EvalSettings&);
const char* evaluator_backend(bool force_scalar=false);
bool packed_coverage_enabled();
}

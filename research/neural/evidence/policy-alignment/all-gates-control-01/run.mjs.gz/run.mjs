import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {boundedProcess} from '../../../scripts/neural/bounded-process.mjs';
import {comparePolicyRanking} from '../../../scripts/neural/policy-ranking-quality.mjs';
const root='runs/neural/all-gates-control-01', binary=root+'/diagnostics';
const read=p=>JSON.parse(fs.readFileSync(p)), hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const models=[['initial','runs/neural/v4-initialization/model.blzn'],...[101,211,307].map(s=>['seed-'+s,`runs/neural/policy-ranking-06/training/${s}/step-8192.blzn`])];
const report={complete:false,score:null,remote_ready:false,models:models.map(([name,path])=>({name,path,sha256:hash(path)})),binary_sha256:hash(binary),tasks:[],comparisons:[]};
const save=()=>fs.writeFileSync(root+'/report.json',JSON.stringify(report,null,2)+'\n');save();
const env={...process.env,VK_DRIVER_FILES:'/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json'};for(const k of ['DISPLAY','WAYLAND_DISPLAY','VK_ICD_FILENAMES'])delete env[k];
try{
for(const uv of [true,false]){
 const settings={...read('research/neural/teacher-capability-quality.json'),preserve_uv:uv,gpu_memory_mib:1024};
 const sp=root+`/settings-uv${Number(uv)}.json`;fs.writeFileSync(sp,JSON.stringify(settings,null,2)+'\n');
 let base;
 for(const [name,model] of models){
  const out=root+`/audit-uv${Number(uv)}-${name}.json`,log=fs.openSync(out+'.log','wx'),start=Date.now();
  const process=await boundedProcess(binary,['--audit-model','research/neural/action-diagnostic.json',model,sp,out],{maximum:300000,env,stdio:['ignore',log,log]});fs.closeSync(log);
  report.tasks.push({name,uv,process,seconds:(Date.now()-start)/1000});save();console.log(JSON.stringify(report.tasks.at(-1)));if(!process.success)throw Error('Audit failed');
  const audit=read(out);if(name==='initial')base=audit;else report.comparisons.push({uv,name,...comparePolicyRanking(base,audit)});save();
 }
}
report.complete=true;
}catch(error){report.error=String(error);throw error;}finally{save();}

import fs from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const root = 'runs/neural/policy-ranking-13/data';
const sources = [];
const hash = b => createHash('sha256').update(b).digest('hex');
const read = (p, expected) => {
  const b = fs.readFileSync(p), sha256 = hash(b);
  if (expected) assert.equal(sha256, expected);
  sources.push({ path: p, sha256 }); return b;
};
const m = read('runs/neural/v4-initialization/model.blzn');
assert.equal(m.toString('ascii', 0, 8), 'BLZNET01');
assert.equal(m.readUInt32LE(8), 4);
assert.equal(hash(m.subarray(0, -64)), m.toString('ascii', m.length - 64));
const payload = m.subarray(20 + m.readUInt32LE(16), -64);
const w = Array.from({length:payload.length/4}, (_,i)=>payload.readFloatLE(4*i));
const results=[];
for (const name of fs.readdirSync(root).sort()) {
  const p=root+'/'+name;
  if(!fs.existsSync(p+'/index.json'))continue;
  const ix=JSON.parse(read(p+'/index.json'));
  if(!ix.complete)continue;
  const b=read(p+'/actions.bin',ix.sha256);
  assert.equal(b.toString('ascii',0,8),'BLZACT06');
  const count=Number(b.readBigUInt64LE(8)),x=b.subarray(16,16+4*count);
  const active=[new Uint32Array(64),new Uint32Array(64)];
  const lo=Array(128).fill(Infinity),hi=Array(128).fill(-Infinity);
  const n=count/128;let zero=0;
  for(let row=0;row<n;++row){
    const input=Array.from({length:128},(_,c)=>x.readFloatLE((row*128+c)*4));
    for(let c=0;c<128;++c){assert(Number.isFinite(input[c]));lo[c]=Math.min(lo[c],input[c]);hi[c]=Math.max(hi[c],input[c]);}
    const first=new Float64Array(64),second=new Float64Array(64);
    for(let j=0;j<64;++j){let s=w[8192+j];for(let c=0;c<128;++c)s+=w[j*128+c]*input[c];first[j]=Math.max(0,s);active[0][j]+=s>0;}
    for(let j=0;j<64;++j){let s=w[12352+j];for(let c=0;c<64;++c)s+=w[8256+j*64+c]*first[c];second[j]=Math.max(0,s);active[1][j]+=s>0;}
    zero+=!second.some(x=>x>0);
  }
  results.push({dataset:name,rows:n,zero_embedding_rows:zero,
    layers:active.map(a=>({dead_units:a.filter(n=>n===0).length,always_active_units:a.filter(v=>v===n).length,activation_fractions:Array.from(a,v=>v/n)})),
    feature_ranges:lo.map((minimum,i)=>({feature:i,minimum,maximum:hi[i]}))});
}
const result={score:null,note:'Read-only CPU double accumulation, descriptive activation audit only; not a native numerical parity test or proof of task capacity.',
  uv_condition_weights_all_zero:Array.from({length:64},(_,r)=>w[r*128+79]).every(x=>x===0),results,sources};
fs.writeFileSync('runs/neural/endpoint-representation-01/report.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({uv_condition_weights_all_zero:result.uv_condition_weights_all_zero,results:results.map(r=>({dataset:r.dataset,rows:r.rows,zero_embedding_rows:r.zero_embedding_rows,layers:r.layers.map(({dead_units,always_active_units})=>({dead_units,always_active_units})),largest_feature_magnitude:Math.max(...r.feature_ranges.flatMap(x=>[Math.abs(x.minimum),Math.abs(x.maximum)]))}))},null,2));

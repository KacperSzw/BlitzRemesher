import fs from 'node:fs';
import assert from 'node:assert/strict';
import {boundedProcess} from '../../../scripts/neural/bounded-process.mjs';
import {auditMetrics,auditTermination} from '../../../scripts/neural/quality-metrics.mjs';
const directory='runs/neural/endpoint-support-initial-01';
const read=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const write=(p,v)=>fs.writeFileSync(p,JSON.stringify(v,null,2)+'\n');
const hypothesis=read(directory+'/hypothesis.json');
const log=fs.openSync(directory+'/native.log','wx');
const began=new Date().toISOString();
let processResult;
try {
 processResult=await boundedProcess('build/neural/blitz-neural-diagnostics',[
  '--audit-model',directory+'/manifest.json',hypothesis.model.path,
  directory+'/settings.json',directory+'/audit.json'
 ],{maximum:hypothesis.maximum_ms,stdio:['ignore',log,log]});
} finally {fs.closeSync(log);}
const result={version:1,started:began,finished:new Date().toISOString(),process:processResult,complete:false,score:null,remote_ready:false};
try {
 assert(processResult.success,'Native diagnostic did not finish cleanly');
 const audit=read(directory+'/audit.json');
 auditMetrics(audit);
 const termination=auditTermination(audit);
 assert(termination.known && !termination.reasons.cancelled && !termination.reasons.resource,'Unknown or interrupted execution');
 const before=read(hypothesis.baseline.path),unrestricted=read(hypothesis.unrestricted_trained.path);
 assert.equal(audit.visual_settings_sha256,before.visual_settings_sha256);
 assert.equal(audit.model_sha256,hypothesis.model.sha256);
 assert.equal(audit.binary_sha256,hypothesis.binary_sha256);
 const row=audit.rows[0];
 assert.equal(row.asset,'ph_moon_rock_02');
 assert.equal(row.ranking,'learned');
 for(const lod of row.lods.slice(1)) for(const [measurement,limit] of [[lod.source,lod.source_limit],[lod.adjacent,lod.transition_limit]]) {
  assert(measurement.complete && measurement.passed && !measurement.cancelled && !measurement.resource_limited && !measurement.nonfinite_error);
  for(const key of ['error_px','coverage_upper_px']) assert(Number.isFinite(measurement[key]) && measurement[key]>=0 && measurement[key]<=limit);
  assert(Number.isFinite(measurement.changed_area) && measurement.changed_area>=0 && measurement.changed_area<=audit.visual_settings.max_changed_area);
 }
 const select=a=>a.rows.find(r=>r.asset===row.asset && r.ranking==='learned').lods.map(l=>l.triangles);
 const base=select(before),failed=select(unrestricted),supported=row.lods.map(l=>l.triangles);
 assert.equal(supported.length,base.length);
 assert.equal(supported[0],base[0]);
 const comparisons=base.slice(1).map((triangles,i)=>({level:i+1,initial:triangles,unrestricted_trained:failed[i+1],supported_trained:supported[i+1],relative_increase:supported[i+1]/triangles-1}));
 const records=row.supported_rankings;
 assert(records.length>0 && records.every(r=>r.pool>=1 && r.pool<=16 && Number.isFinite(r.global_top_score) && Number.isFinite(r.support_top_score) && r.support_top_score<=r.global_top_score));
 const escaped=records.filter(r=>!r.global_top_in_support).length;
 Object.assign(result,{complete:true,passed:comparisons.every(r=>r.relative_increase<=hypothesis.maximum_relative_per_lod_increase),scope:'Support-mismatch diagnostic only; no pilot gate or independent neural deployment claim',comparisons,rescores:records.length,global_top_outside_support:escaped,global_top_escape_fraction:escaped/records.length,termination,seconds:audit.seconds});
} catch(error) {result.error=String(error);}
write(directory+'/result.json',result);
console.log(JSON.stringify(result,null,2));
if(!result.complete)process.exitCode=1;

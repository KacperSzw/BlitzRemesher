import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
const directory = 'runs/neural/execution-diagnostic-01';
const report = JSON.parse(fs.readFileSync(directory + '/report.json'));
const rows = [], sources = [];
for (const task of report.tasks) {
  if (task.status !== 0) continue;
  const bytes = fs.readFileSync(task.output);
  sources.push({ path: task.output, sha256: createHash('sha256').update(bytes).digest('hex') });
  const audit = JSON.parse(bytes);
  for (const row of audit.rows.filter(x => x.ranking === 'learned')) {
    const proposals = row.neural.action_proposals.map((p, index) => {
      const trace = row.execution_trace.filter(t => t.proposal === index);
      const accepted = trace.filter(t => t.accepted), rejected = trace.filter(t => !t.accepted);
      assert.equal(p.action_trials, trace.length);
      assert.equal(p.accepted_batches, accepted.length);
      const histogram = values => Object.fromEntries([...new Set(values)].sort((a, b) => a - b)
        .map(value => [value, values.filter(x => x === value).length]));
      const sequences = [];
      for (const t of trace) {
        const key = t.iteration + '/' + t.first_rank;
        if (sequences.at(-1)?.key !== key) sequences.push({ key, sizes: [], verdicts: [] });
        sequences.at(-1).sizes.push(t.actions.length);
        sequences.at(-1).verdicts.push(t.accepted);
      }
      return { index, ...p, selected_sizes: histogram(trace.map(t => t.actions.length)),
        accepted_sizes: histogram(accepted.map(t => t.actions.length)),
        rejected_gates: histogram(rejected.map(t => t.failed_gate)),
        triangles_removed: accepted.reduce((s, t) => s + t.faces_before - t.faces_after, 0),
        singleton_rejections: rejected.filter(t => t.actions.length === 1).length,
        accepted_actions: accepted.reduce((s, t) => s + t.actions.length, 0),
        wasted_prefix_trials: sequences.filter(s => s.sizes.at(-1) === 1 && !s.verdicts.at(-1))
          .reduce((s, p) => s + p.sizes.length, 0),
        backoff_sequences: sequences.filter(s => s.sizes.length > 1).map(({ sizes, verdicts }) => ({ sizes, verdicts })) };
    });
    rows.push({ task: task.name, asset: row.asset, triangles: row.lods.map(l => l.triangles), proposals });
  }
}
fs.writeFileSync(directory + '/trace-analysis.json', JSON.stringify({ score: null, complete: report.complete, sources, rows }, null, 2) + '\n');
for (const row of rows.filter(r => r.asset === 'ph_moon_rock_02')) {
  const p = row.proposals.find(p => p.output === 'reuse');
  console.log(row.task, p && { final: p.final_triangles, trials: p.action_trials, accepted: p.accepted_batches,
    removed: p.triangles_removed, selected: p.selected_sizes, accepted_sizes: p.accepted_sizes,
    rejected_gates: p.rejected_gates, singleton_rejections: p.singleton_rejections,
    wasted_prefix_trials: p.wasted_prefix_trials });
}

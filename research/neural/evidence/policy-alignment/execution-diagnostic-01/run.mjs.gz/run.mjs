import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { spawnSync, execFileSync } from 'node:child_process';
import { comparePolicyRanking } from '../../../scripts/neural/policy-ranking-quality.mjs';

const directory = 'runs/neural/execution-diagnostic-01';
const read = p => JSON.parse(fs.readFileSync(p));
const write = (p, x) => fs.writeFileSync(p, JSON.stringify(x, null, 2) + '\n');
const hash = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const binary = 'build/neural/blitz-neural-diagnostics';
const manifest = 'research/neural/action-diagnostic.json';
const originalSettings = 'research/neural/teacher-capability-quality.json';
const models = [{ name: 'initial', path: 'runs/neural/v4-initialization/model.blzn' },
  ...[101, 211, 307].map(seed => ({ name: 'early-' + seed,
    path: `runs/neural/policy-ranking-10/training/${seed}/step-512.blzn` })),
  { name: 'long-101', path: 'runs/neural/policy-ranking-09/training/101/step-8192.blzn' }];
assert(!fs.existsSync(path.join(directory, 'report.json')));
const identity = { head: execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(),
  binary: { path: binary, sha256: hash(binary) }, manifest_sha256: hash(manifest),
  settings_sha256: hash(originalSettings), models: models.map(m => ({ ...m, sha256: hash(m.path) })) };
fs.writeFileSync(path.join(directory, 'source.patch'), execFileSync('git', ['diff', '--binary']));
identity.source_patch_sha256 = hash(path.join(directory, 'source.patch'));
write(path.join(directory, 'identity.json'), identity);
const report = { complete: false, score: null, remote_ready: false,
  purpose: 'Existing-weight diagnosis after fair hook scheduling, native per-trial execution traces; no training.',
  tasks: [], comparisons: [] };
const persist = () => write(path.join(directory, 'report.json'), report);
const began = Date.now();
persist();
try {
  for (const uv of [true, false]) {
    const settings = { ...read(originalSettings), gpu_memory_mib: 1024, preserve_uv: uv,
      trace_execution: true };
    const settingsFile = path.join(directory, `settings-uv${Number(uv)}.json`);
    write(settingsFile, settings);
    let baseline;
    for (const model of models) {
      assert(Date.now() - began < 20 * 60000, 'diagnostic exceeded total work cap');
      assert.equal(hash(binary), identity.binary.sha256);
      assert.equal(hash(model.path), identity.models.find(x => x.name === model.name).sha256);
      const name = `uv${Number(uv)}-${model.name}`;
      const output = path.join(directory, name + '.json');
      const log = fs.openSync(path.join(directory, name + '.log'), 'wx');
      const start = Date.now();
      const result = spawnSync(binary, ['--audit-model', manifest, model.path, settingsFile, output],
        { stdio: ['ignore', log, log], timeout: 300000, killSignal: 'SIGTERM' });
      fs.closeSync(log);
      report.tasks.push({ name, status: result.status, signal: result.signal,
        seconds: (Date.now() - start) / 1000, output });
      persist();
      assert.equal(result.status, 0, 'native audit failed: ' + name);
      const audit = read(output); assert(audit.complete, 'incomplete native audit: ' + name);
      if (model.name === 'initial') baseline = audit;
      else report.comparisons.push({ preserve_uv: uv, model: model.name,
        ...comparePolicyRanking(baseline, audit) });
      persist();
      console.log(name, 'complete', Math.round((Date.now() - start) / 1000), 'seconds');
    }
  }
  report.complete = true;
} catch (e) {
  report.error = String(e); process.exitCode = 1;
} finally { report.seconds = (Date.now() - began) / 1000; persist(); }

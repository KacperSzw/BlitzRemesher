import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const output = dirname(fileURLToPath(import.meta.url));
const sources = [];
const sha = b => createHash('sha256').update(b).digest('hex');
const read = path => {
  const bytes = fs.readFileSync(path);
  sources.push({ path, bytes: bytes.length, sha256: sha(bytes) });
  return bytes;
};
const json = path => JSON.parse(read(path));
function model(path) {
  const b = read(path), shaped = b.toString('ascii', 0, 8) === 'BLZNET02';
  assert.equal(b.readUInt32LE(8), 4);
  assert.equal(shaped ? b.readUInt32LE(20) : 64, 64);
  assert.equal(sha(b.subarray(0, -64)), b.toString('ascii', b.length - 64));
  const payload = b.subarray((shaped ? 24 : 20) + b.readUInt32LE(16), -64);
  assert.equal(payload.length, b.readUInt32LE(12) * 4);
  const w = Array.from({ length: payload.length / 4 }, (_, i) => payload.readFloatLE(i * 4));
  return { path, payload, w, row: w.slice(12416, 12480), bias: w[13184] };
}
const initial = model('runs/neural/v4-initialization/model.blzn');
const dot = (a, b) => a.reduce((sum, v, i) => sum + v * b[i], 0);
const norm = a => Math.sqrt(dot(a, a));
const models = [initial];
const replay = [];
for (const seed of [101, 211, 307]) {
  const longEarly = model(`runs/neural/policy-ranking-09/training/${seed}/step-512.blzn`);
  const early = model(`runs/neural/policy-ranking-10/training/${seed}/step-512.blzn`);
  const final = model(`runs/neural/policy-ranking-09/training/${seed}/step-8192.blzn`);
  replay.push({ seed, trained_payload_equal: longEarly.payload.equals(early.payload),
    long_early_sha256: sha(longEarly.payload), short_final_sha256: sha(early.payload) });
  models.push(early, final);
}
for (const m of models) {
  for (let i = 0; i < m.w.length; ++i)
    if (!(i >= 12416 && i < 12480) && i !== 13184) assert.equal(m.w[i], initial.w[i]);
  m.delta = m.row.map((v, i) => v - initial.row[i]);
  m.values = []; m.centeredSquared = 0; m.pairs = 0; m.correct = 0; m.hinge = 0;
  m.quality = { uv_on: { states: 0, pairs: 0, correct: 0, state_accuracy: 0 },
    uv_off: { states: 0, pairs: 0, correct: 0, state_accuracy: 0 } };
}
function hidden(x) {
  const h0 = new Float64Array(64), h1 = new Float64Array(64), w = initial.w;
  for (let r = 0; r < 64; ++r) {
    let s = w[8192 + r];
    for (let c = 0; c < 128; ++c) s += w[r * 128 + c] * x[c];
    h0[r] = Math.max(0, s);
  }
  for (let r = 0; r < 64; ++r) {
    let s = w[12352 + r];
    for (let c = 0; c < 64; ++c) s += w[8256 + r * 64 + c] * h0[c];
    h1[r] = Math.max(0, s);
  }
  return h1;
}
const changes = [], totals = { states: 0, rows: 0, changed_states: 0, changed_bits: 0,
  search_area_exceeds_old_margin: 0 };
const root = 'runs/neural/policy-ranking-09/data';
for (const name of json(root + '/index.json').datasets) {
  const dir = `${root}/${name}`, index = json(dir + '/index.json');
  const contract = json(dir + '/contract.json');
  assert.equal(contract.visual_settings.max_changed_area, 0.5);
  const trajectoryBytes = read(dir + '/trajectory.json'), requestBytes = read(dir + '/requests.json');
  assert.equal(sha(trajectoryBytes), index.trajectory_sha256);
  assert.equal(sha(requestBytes), index.requests_sha256);
  const requests = new Map(JSON.parse(requestBytes).map(x => [x.proposal, x]));
  const trajectory = JSON.parse(trajectoryBytes);
  const b = read(dir + '/actions.bin');
  assert.equal(sha(b), index.sha256);
  assert.equal(b.toString('ascii', 0, 8), 'BLZACT06');
  let cursor = 8;
  function vector(stride) {
    const n = Number(b.readBigUInt64LE(cursor)); cursor += 8;
    const v = b.subarray(cursor, cursor + n * stride); cursor += v.length; return v;
  }
  const x = vector(4), labels = vector(1), offsets = vector(4);
  for (const state of trajectory) {
    const first = offsets.readUInt32LE(state.state * 4), end = offsets.readUInt32LE((state.state + 1) * 4);
    const request = requests.get(state.proposal), old = [], full = [], embeddings = [];
    for (let row = first; row < end; ++row) {
      const observed = state.rows[row - first];
      const features = Array.from({ length: 128 }, (_, c) => x.readFloatLE((row * 128 + c) * 4));
      embeddings.push(hidden(features));
      let margin = Infinity, fullMargin = Infinity;
      const passed = (labels[row] & 27) === 27;
      if (passed) {
        margin = Math.max(observed.source.error / request.source_limit,
          observed.adjacent.error / request.adjacent_limit,
          observed.source_search.error / request.source_limit,
          observed.adjacent_search.error / request.adjacent_limit,
          observed.source.changed_area / 0.5, observed.adjacent.changed_area / 0.5);
        fullMargin = Math.max(margin, observed.source_search.changed_area / 0.5,
          observed.adjacent_search.changed_area / 0.5);
        totals.search_area_exceeds_old_margin += fullMargin > margin;
      }
      old.push({ faces: state.triangles - 2 * features[65], margin });
      full.push({ faces: state.triangles - 2 * features[65], margin: fullMargin });
    }
    function preferred(rows) {
      let faces = Infinity, margin = Infinity, mask = 0;
      rows.forEach((r, i) => {
        if (!Number.isFinite(r.margin)) return;
        if (r.faces < faces || (r.faces === faces && r.margin < margin)) {
          faces = r.faces; margin = r.margin; mask = 0;
        }
        if (r.faces === faces && r.margin === margin) mask |= 1 << i;
      });
      return mask;
    }
    const oldMask = preferred(old), fullMask = preferred(full);
    assert.equal(oldMask, state.preferred_mask);
    if (oldMask !== fullMask) {
      const bits = (oldMask ^ fullMask).toString(2).split('1').length - 1;
      ++totals.changed_states; totals.changed_bits += bits;
      changes.push({ dataset: name, state: state.state, old_mask: oldMask, full_mask: fullMask });
    }
    for (const m of models) {
      const scores = embeddings.map(h => dot(m.row, h) + m.bias);
      m.values.push(...scores);
      const mean = scores.reduce((a, b) => a + b, 0) / scores.length;
      m.centeredSquared += scores.reduce((s, x) => s + (x - mean) ** 2, 0);
      let qualityPairs = 0, qualityCorrect = 0;
      for (let p = 0; p < full.length; ++p)
        for (let n = 0; n < full.length; ++n)
          if (Number.isFinite(full[p].margin) && Number.isFinite(full[n].margin) &&
              full[p].faces === full[n].faces && full[p].margin < full[n].margin) {
            ++qualityPairs; qualityCorrect += scores[p] > scores[n];
          }
      if (qualityPairs) {
        const bucket = m.quality[contract.preserve_uv ? 'uv_on' : 'uv_off'];
        ++bucket.states; bucket.pairs += qualityPairs; bucket.correct += qualityCorrect;
        bucket.state_accuracy += qualityCorrect / qualityPairs;
      }
      for (let p = first; p < end; ++p)
        if ((labels[p] & 28) === 28)
          for (let n = first; n < end; ++n)
            if ((labels[n] & 28) === 24) {
              const gap = scores[p - first] - scores[n - first];
              ++m.pairs; m.correct += gap > 0; m.hinge += Math.max(0, 1 - gap);
            }
    }
    ++totals.states; totals.rows += end - first;
  }
}
const report = { score: null, note: 'Read-only CPU double-accumulated scores; descriptive, not native numerical equivalence or proof of optimizer causation. Adam preconditioning can move outside the pair-gradient span even with no penalty.',
  full_margin: totals, changes, checkpoint_replay: replay,
  models: models.map(m => ({ path: m.path, rank_norm: norm(m.row), delta_norm: norm(m.delta),
    cosine_with_negative_initial: norm(m.delta) ? -dot(m.delta, initial.row) / norm(m.delta) / norm(initial.row) : null,
    bias: m.bias, bias_delta: m.bias - initial.bias,
    score_mean: m.values.reduce((a, b) => a + b, 0) / m.values.length,
    score_rms: Math.sqrt(dot(m.values, m.values) / m.values.length),
    within_state_score_rms: Math.sqrt(m.centeredSquared / m.values.length),
    pooled_pair_accuracy: m.correct / m.pairs, pooled_pair_hinge: m.hinge / m.pairs,
    same_removal_passing_quality: Object.fromEntries(Object.entries(m.quality).map(([uv, q]) =>
      [uv, { states: q.states, pairs: q.pairs, pooled_accuracy: q.correct / q.pairs,
        equal_state_accuracy: q.state_accuracy / q.states }])) })), sources };
fs.writeFileSync(resolve(output, 'report.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ ...report, sources: undefined, changes: undefined }, null, 2));

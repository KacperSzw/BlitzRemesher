import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { boundedProcess } from '../../../scripts/neural/bounded-process.mjs';
import { comparePolicyRanking } from '../../../scripts/neural/policy-ranking-quality.mjs';
const dir = 'runs/neural/policy-ranking-scope-01';
const read = p => JSON.parse(fs.readFileSync(p));
const hash = p => createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const binary = 'build/neural/blitz-neural-diagnostics', manifest = 'research/neural/action-diagnostic.json';
const models = [{ name: 'initial', path: 'runs/neural/v4-initialization/model.blzn' },
  ...[101,211,307].map(seed => ({name:'seed-'+seed,path:`runs/neural/policy-ranking-03/training/${seed}/step-8192.blzn`}))];
const report = { complete:false,score:null,remote_ready:false,rows:[],comparisons:[],
 identity:{binary:hash(binary),manifest:hash(manifest),models:models.map(x=>({...x,sha256:hash(x.path)}))} };
const persist = () => fs.writeFileSync(dir+'/report.json',JSON.stringify(report,null,2)+'\n');
const env = {...process.env,VK_DRIVER_FILES:'/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json'};
for(const k of ['DISPLAY','WAYLAND_DISPLAY','VK_ICD_FILENAMES'])delete env[k];
try {
 for(const preserve of [true,false]) {
  const settings={...read('research/neural/teacher-capability-quality.json'),preserve_uv:preserve,gpu_memory_mib:1024};
  settings.research.output='rebuild';
  const settingsPath=dir+`/settings-uv${Number(preserve)}.json`;
  fs.writeFileSync(settingsPath,JSON.stringify(settings,null,2)+'\n');
  let initial;
  for(const model of models) {
   if(hash(binary)!==report.identity.binary)throw Error('binary changed');
   const name=`uv${Number(preserve)}-${model.name}`,output=dir+'/'+name+'.json',fd=fs.openSync(dir+'/'+name+'.log','wx');
   let process;
   try {process=await boundedProcess(binary,['--audit-model',manifest,model.path,settingsPath,output],{maximum:180000,env,stdio:['ignore',fd,fd]});}
   finally{fs.closeSync(fd);}
   if(!process.success)throw Error('audit failed '+name);
   const audit=read(output);report.rows.push({name,process,output,sha256:hash(output)});
   if(model.name==='initial')initial=audit;
   else report.comparisons.push({name,...comparePolicyRanking(initial,audit)});
   persist();console.log(name,audit.rows.filter(r=>r.ranking==='learned').map(r=>r.lods.map(l=>l.triangles)));
  }
 }
 report.complete=true;
}catch(e){report.error=String(e);throw e;}finally{persist();}

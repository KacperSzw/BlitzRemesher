import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {isDeepStrictEqual} from 'node:util';
import {boundedProcess} from '../../../scripts/neural/bounded-process.mjs';
const dir='runs/neural/sequential-gate-parity-01';
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const identity=JSON.parse(fs.readFileSync(dir+'/identity.json'));
const binaries={exact:dir+'/exact-diagnostics',certified:dir+'/certified-diagnostics'};
const hashes=Object.fromEntries(Object.entries(binaries).map(([k,p])=>[k,hash(p)]));
const report={complete:false,passed:false,score:null,timing_authority:'local_shared',started_at:new Date().toISOString(),identity,binaries:hashes,tasks:[],comparisons:[]};
const save=()=>fs.writeFileSync(dir+'/report.json',JSON.stringify(report,null,2)+'\n');
const deadline=Date.now()+30*60000;
const env={...process.env,VK_DRIVER_FILES:'/run/opengl-driver/share/vulkan/icd.d/nvidia_icd.json'};
for(const k of ['DISPLAY','WAYLAND_DISPLAY','VK_ICD_FILENAMES'])delete env[k];
const strip=v=>Array.isArray(v)?v.map(strip):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).filter(([k])=>k!=='seconds'&&!k.endsWith('_seconds')).map(([k,x])=>[k,strip(x)])):v;
try {
 for(const uv of [true,false]) {
  for(const side of ['exact','certified']) {
   const name=side+'-uv'+Number(uv),output=dir+'/'+name+'.json';
   if(hash(binaries[side])!==hashes[side])throw Error('Pinned binary changed');
   const fd=fs.openSync(dir+'/'+name+'.log','wx'),start=Date.now();let result;
   try {result=await boundedProcess(binaries[side],['--audit-model','research/neural/action-diagnostic.json','runs/neural/v4-initialization/model.blzn',dir+'/settings-uv'+Number(uv)+'.json',output],{maximum:Math.min(8*60000,deadline-Date.now()),env,stdio:['ignore',fd,fd]});}finally{fs.closeSync(fd);}
   report.tasks.push({name,seconds:(Date.now()-start)/1000,process:result});save();console.log(JSON.stringify(report.tasks.at(-1)));
   if(!result.success)throw Error('Parity task failed: '+name);
   const audit=JSON.parse(fs.readFileSync(output));
   if(!audit.complete||audit.binary_sha256!==hashes[side]||audit.model_sha256!==identity.model_sha256||audit.manifest_sha256!==identity.manifest_sha256)throw Error('Incomplete or changed parity inputs');
   for(const row of audit.rows)if(row.neural.resource_failures||row.neural.confirmation_cancelled||row.neural.confirmation_nonfinite)throw Error('Parity comparison crossed a resource/cancellation boundary');
  }
  const before=JSON.parse(fs.readFileSync(dir+'/exact-uv'+Number(uv)+'.json'));
  const after=JSON.parse(fs.readFileSync(dir+'/certified-uv'+Number(uv)+'.json'));
  if(before.rows.length!==after.rows.length)throw Error('Missing parity rows');
  for(let i=0;i<before.rows.length;i++) {
   const a=before.rows[i],b=after.rows[i];
   const stable=r=>({asset:r.asset,status:r.status,lods:r.lods,trace:r.execution_trace,proposals:strip(r.neural.action_proposals),counts:['action_ranked','action_trials','legal_collapses','rejected_collapses','bounded_audits'].map(k=>r.neural[k])});
   if(!isDeepStrictEqual(stable(a),stable(b)))throw Error('Real-asset gate trajectory or exact final measurements differ: '+a.asset+' uv'+Number(uv));
   report.comparisons.push({asset:a.asset,preserve_uv:uv,passed:true,ordered_trials:a.execution_trace.length,emitted_meshes:a.lods.map(l=>l.mesh_sha256),seconds:{exact:a.seconds,certified:b.seconds},audit_seconds:{exact:a.neural.gpu_audit_seconds,certified:b.neural.gpu_audit_seconds},sparse_passes:b.neural.gpu_sparse_passes,sparse_failures:b.neural.gpu_sparse_failures,sparse_fallbacks:b.neural.gpu_sparse_fallbacks});save();
  }
 }
 report.complete=report.passed=true;
}catch(error){report.error=String(error);throw error;}finally{report.finished_at=new Date().toISOString();save();}

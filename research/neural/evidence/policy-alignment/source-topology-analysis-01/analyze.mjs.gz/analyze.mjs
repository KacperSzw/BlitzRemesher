import fs from 'node:fs';
import { createHash } from 'node:crypto';

const variants = [
  'policy-ranking-08/data/ph_mountainside-uv1-learned-source512',
  'policy-ranking-08/data/ph_yellow_onion-uv1-learned-source512',
  'reuse-source-rock-01',
  'reuse-source-onion-01',
  'reuse-source-crab-01',
  'merged-source-rock-01',
];
const rows = variants.map((variant) => {
  const directory = 'runs/neural/' + variant;
  const file = directory + '/source-reference.bin';
  const data = fs.readFileSync(file);
  if (data.subarray(0, 8).toString() !== 'BLZMREF2') throw Error('Wrong reference format');
  let at = 8;
  const vectors = [12, 12, 8, 4, 16, 4, 2, 1, 4].map((stride) => {
    const count = Number(data.readBigUInt64LE(at));
    at += 8;
    const bytes = count * stride;
    const result = { count, data: data.subarray(at, at + bytes) };
    at += bytes;
    return result;
  });
  if (at !== data.length) throw Error('Reference dimensions');
  const [positions, , , , , indices] = vectors;
  const used = new Set(Array.from({ length: indices.count }, (_, i) => indices.data.readUInt32LE(i * 4)));
  const groups = new Map(), ids = new Map();
  for (const vertex of used) {
    if (vertex >= positions.count) throw Error('Index outside positions');
    const key = [0, 4, 8].map((offset) => positions.data.readFloatLE(vertex * 12 + offset)).join(',');
    if (!groups.has(key)) groups.set(key, { id: groups.size, count: 0 });
    groups.get(key).count++;
    ids.set(vertex, groups.get(key).id);
  }
  const edges = new Map(), histogram = {};
  for (const { count } of groups.values()) histogram[count] = (histogram[count] ?? 0) + 1;
  for (let face = 0; face < indices.count / 3; face++) {
    const triangle = [0, 1, 2].map((i) => ids.get(indices.data.readUInt32LE((face * 3 + i) * 4)));
    for (let i = 0; i < 3; i++) {
      const a = triangle[i], b = triangle[(i + 1) % 3];
      const key = Math.min(a, b) + ':' + Math.max(a, b);
      edges.set(key, (edges.get(key) ?? 0) + 1);
    }
  }
  const index = JSON.parse(fs.readFileSync(directory + '/index.json'));
  return {
    variant, reference_sha256: createHash('sha256').update(data).digest('hex'),
    triangles: indices.count / 3, used_attribute_vertices: used.size,
    geometric_positions: groups.size, attribute_copies_per_position: histogram,
    geometric_edges: edges.size,
    boundary_edges: [...edges.values()].filter((n) => n === 1).length,
    nonmanifold_edges: [...edges.values()].filter((n) => n > 2).length,
    observed_states: index.states, informative_states: index.ranking_states,
    native_verification: index.verification,
  };
});
fs.writeFileSync('runs/neural/source-topology-analysis-01/report.json', JSON.stringify({
  score: null, note: 'Attribute-copy counts are raw source storage, not a claim that every copy remains distinct after UV-mode canonicalization.', rows,
}, null, 2) + '\n');
console.log(rows.map((r) => ({ variant: r.variant, triangles: r.triangles, vertices: r.used_attribute_vertices, positions: r.geometric_positions, informative: r.informative_states })));

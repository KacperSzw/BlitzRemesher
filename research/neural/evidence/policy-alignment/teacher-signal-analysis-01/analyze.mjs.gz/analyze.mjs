import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { resolve, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Read-only analysis of retained teacher artifacts. No inference or GPU work.
const root = resolve(process.argv[2] ?? 'runs/neural/policy-ranking-09/data');
const output = dirname(fileURLToPath(import.meta.url));
const sources = [];
const sha = value => createHash('sha256').update(value).digest('hex');
function read(path) {
  const bytes = readFileSync(path);
  sources.push({ path: relative(process.cwd(), path), bytes: bytes.length, sha256: sha(bytes) });
  return bytes;
}
const json = path => JSON.parse(read(path));
const classNames = ['only_cardinality_all_pass_equal_margin', 'only_feasibility_equal_removal',
  'only_margin_equal_removal', 'only_geometry', 'mixed', 'uninformative'];
const pairNames = ['cardinality', 'margin_equal_removal', 'feasibility_equal_removal',
  'feasibility_different_removal', 'geometry'];
const emptyCounts = names => Object.fromEntries(names.map(name => [name, 0]));
const states = [];
const featurePairs = new Map();
let conflictingPairs = 0;
let totalRows = 0;
let duplicateFeatureViolations = 0;
let initializerColumn79Checked = false;
for (const name of json(root + '/index.json').datasets) {
  const dir = root + '/' + name;
  const index = json(dir + '/index.json');
  const contractBytes = read(dir + '/contract.json');
  assert.equal(sha(contractBytes), index.contract_sha256);
  const contract = JSON.parse(contractBytes);
  assert.equal(contract.teacher_target, 'runtime-endpoint-v2');
  assert.equal(contract.visual_settings.max_changed_area, 0.5);
  if (!initializerColumn79Checked) {
    const model = read(resolve(contract.job.model));
    assert.equal(sha(model), contract.model_sha256);
    const header = model.toString('ascii', 0, 8);
    assert(['BLZNET01', 'BLZNET02'].includes(header));
    const width = header === 'BLZNET02' ? model.readUInt32LE(20) : 64;
    const offset = (header === 'BLZNET02' ? 24 : 20) + model.readUInt32LE(16);
    for (let row = 0; row < width; ++row)
      assert.equal(model.readFloatLE(offset + (row * 128 + 79) * 4), 0);
    initializerColumn79Checked = true;
  }
  const trajectoryBytes = read(dir + '/trajectory.json');
  const requestBytes = read(dir + '/requests.json');
  const bytes = read(dir + '/actions.bin');
  const geometry = read(dir + '/geometry-rejected.bin');
  assert.equal(sha(bytes), index.sha256);
  assert.equal(sha(trajectoryBytes), index.trajectory_sha256);
  assert.equal(sha(requestBytes), index.requests_sha256);
  assert.equal(sha(geometry), index.geometry_rejected_sha256);
  const trajectory = JSON.parse(trajectoryBytes);
  const requests = new Map(JSON.parse(requestBytes).map(request => [request.proposal, request]));
  assert.equal(bytes.toString('ascii', 0, 8), 'BLZACT06');
  assert.equal(geometry.toString('ascii', 0, 8), 'BLZRANK1');
  let cursor = 8;
  function vector(stride) {
    const count = Number(bytes.readBigUInt64LE(cursor));
    cursor += 8;
    const result = bytes.subarray(cursor, cursor + count * stride);
    cursor += result.length;
    return result;
  }
  const x = vector(4), rawLabels = vector(1), offsets = vector(4), progress = vector(4);
  vector(4); vector(4); vector(4);
  assert.equal(cursor, bytes.length);
  assert.equal(Number(geometry.readBigUInt64LE(8)), Math.ceil(rawLabels.length / 8));
  const hashes = [];
  const value = (row, column) => x.readFloatLE((row * 128 + column) * 4);
  for (let row = 0; row < rawLabels.length; ++row) {
    const normalized = Buffer.from(x.subarray(row * 512, (row + 1) * 512));
    // The frozen initializer's first-layer column79 is zero, so exact-feature
    // contradiction analysis treats the two UV condition values as equivalent.
    normalized.writeFloatLE(0, 79 * 4);
    hashes.push(sha(normalized));
    duplicateFeatureViolations += value(row, 78) !== value(row, 23);
    ++totalRows;
  }
  assert.equal(offsets.length / 4 - 1, trajectory.length);
  for (let s = 0; s < trajectory.length; ++s) {
    const record = trajectory[s], request = requests.get(record.proposal);
    const first = offsets.readUInt32LE(s * 4), end = offsets.readUInt32LE(s * 4 + 4);
    const rows = [];
    for (let row = first; row < end; ++row) {
      const observed = record.rows[row - first];
      const rejected = Boolean((geometry[16 + (row >> 3)] >> (row & 7)) & 1);
      assert.equal(rejected, observed.geometry_rejected);
      const raw = rawLabels[row];
      assert.equal(raw & ~4, observed.known_mask);
      const label = rejected ? 24 : raw;
      if (rejected) assert.equal(raw, 0);
      const passed = (label & 3) === 3;
      const margin = passed ? Math.max(
        observed.source.error / request.source_limit,
        observed.adjacent.error / request.adjacent_limit,
        observed.source_search.error / request.source_limit,
        observed.adjacent_search.error / request.adjacent_limit,
        observed.source.changed_area / 0.5,
        observed.adjacent.changed_area / 0.5) : null;
      rows.push({ row, known: (label & 24) === 24, preferred: Boolean(label & 4),
        passed, rejected, margin, removed: 2 * value(row, 65) });
    }
    const pairCounts = emptyCounts(pairNames);
    for (const positive of rows.filter(row => row.preferred && row.known)) {
      assert(positive.passed && !positive.rejected);
      for (const negative of rows.filter(row => !row.preferred && row.known)) {
        let kind;
        if (negative.rejected) kind = 'geometry';
        else if (!negative.passed) kind = positive.removed === negative.removed
          ? 'feasibility_equal_removal' : 'feasibility_different_removal';
        else if (positive.removed !== negative.removed) {
          assert(positive.removed > negative.removed);
          kind = 'cardinality';
        } else {
          assert(positive.margin < negative.margin);
          kind = 'margin_equal_removal';
        }
        ++pairCounts[kind];
        const key = hashes[positive.row] + '/' + hashes[negative.row];
        const reverse = hashes[negative.row] + '/' + hashes[positive.row];
        conflictingPairs += featurePairs.has(reverse);
        featurePairs.set(key, { dataset: name, state: s });
      }
    }
    const pairs = Object.values(pairCounts).reduce((a, b) => a + b, 0);
    const active = Object.keys(pairCounts).filter(key => pairCounts[key]);
    const allPass = rows.every(row => row.passed);
    const equalMargin = new Set(rows.filter(row => row.passed).map(row => row.margin)).size === 1;
    let kind = 'mixed';
    if (!pairs) kind = 'uninformative';
    else if (active.length === 1) {
      if (active[0] === 'cardinality' && allPass && equalMargin)
        kind = 'only_cardinality_all_pass_equal_margin';
      else if (active[0] === 'feasibility_equal_removal') kind = 'only_feasibility_equal_removal';
      else if (active[0] === 'margin_equal_removal') kind = 'only_margin_equal_removal';
      else if (active[0] === 'geometry') kind = 'only_geometry';
    }
    states.push({ dataset: name, state: s, asset: index.asset, category: index.category,
      uv: value(first, 79), source_triangles: index.source_triangles,
      progress: progress.readFloatLE(s * 4), bin: Math.min(3, Math.floor(progress.readFloatLE(s * 4) * 4)),
      rows: rows.length, pairs, kind, pair_counts: pairCounts,
      coverage_bearing_pairs: pairCounts.margin_equal_removal + pairCounts.feasibility_equal_removal,
      all_pass: allPass, equal_margin: equalMargin, sampler_probability: 0 });
  }
}

// Geometry-only topology check of the two existing diagnostic glTF assets.
// No normals/UV are discarded in execution; this only counts geometric edges.
const diagnosticTopology = [];
for (const name of ['moon_rock_02', 'painted_wooden_shelves']) {
  const file = resolve('data/polyhaven/' + name + '/source.gltf');
  const gltf = json(file);
  const buffers = gltf.buffers.map(buffer => read(resolve(dirname(file), buffer.uri)));
  function accessor(id) {
    const item = gltf.accessors[id], view = gltf.bufferViews[item.bufferView];
    const bytes = buffers[view.buffer];
    const width = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4 }[item.type];
    const size = { 5121: 1, 5123: 2, 5125: 4, 5126: 4 }[item.componentType];
    const method = { 5121: 'readUInt8', 5123: 'readUInt16LE', 5125: 'readUInt32LE',
      5126: 'readFloatLE' }[item.componentType];
    assert(width && size && method && !item.sparse);
    return Array.from({ length: item.count }, (_, i) => {
      const row = Array.from({ length: width }, (_, j) => bytes[method](
        (view.byteOffset ?? 0) + (item.byteOffset ?? 0) +
        i * (view.byteStride ?? width * size) + j * size));
      return width === 1 ? row[0] : row;
    });
  }
  assert.equal(gltf.meshes.length, 1);
  const geometry = new Map(), edges = new Map();
  let vertices = 0, triangles = 0;
  for (const primitive of gltf.meshes[0].primitives) {
    assert.equal(primitive.mode ?? 4, 4);
    const positions = accessor(primitive.attributes.POSITION), indices = accessor(primitive.indices);
    const ids = positions.map(position => {
      const key = position.join(',');
      if (!geometry.has(key)) geometry.set(key, geometry.size);
      return geometry.get(key);
    });
    vertices += positions.length;
    triangles += indices.length / 3;
    for (let face = 0; face < indices.length; face += 3)
      for (let edge = 0; edge < 3; ++edge) {
        const a = ids[indices[face + edge]], b = ids[indices[face + (edge + 1) % 3]];
        const key = Math.min(a, b) + '/' + Math.max(a, b);
        edges.set(key, (edges.get(key) ?? 0) + 1);
      }
  }
  diagnosticTopology.push({ asset: 'ph_' + name, vertices, geometric_vertices: geometry.size,
    triangles, edges: edges.size, boundary_edges: [...edges.values()].filter(n => n === 1).length,
    nonmanifold_edges: [...edges.values()].filter(n => n > 2).length });
}

// Exact probabilities of the implemented category->parent->nonempty bin->state
// sampler, after rank training excludes zero-pair states. Rank-loss-v2 normalizes
// pairs within a state, so each pair receives state probability / pair count.
const categories = new Map();
for (const state of states.filter(state => state.pairs)) {
  if (!categories.has(state.category)) categories.set(state.category, new Map());
  const assets = categories.get(state.category);
  if (!assets.has(state.asset)) assets.set(state.asset, new Map());
  const bins = assets.get(state.asset);
  if (!bins.has(state.bin)) bins.set(state.bin, []);
  bins.get(state.bin).push(state);
}
for (const assets of categories.values())
  for (const bins of assets.values())
    for (const members of bins.values())
      for (const state of members)
        state.sampler_probability = 1 / categories.size / assets.size / bins.size / members.length;

function summarize(members) {
  const classes = emptyCounts(classNames), pairCounts = emptyCounts(pairNames);
  const weightedClasses = emptyCounts(classNames), weightedPairs = emptyCounts(pairNames);
  let totalMass = 0;
  for (const state of members) {
    ++classes[state.kind];
    weightedClasses[state.kind] += state.sampler_probability;
    totalMass += state.sampler_probability;
    for (const key of pairNames) {
      pairCounts[key] += state.pair_counts[key];
      if (state.pairs) weightedPairs[key] += state.sampler_probability * state.pair_counts[key] / state.pairs;
    }
  }
  return { states: members.length, informative: members.filter(state => state.pairs).length,
    states_with_coverage_bearing_pairs: members.filter(state => state.coverage_bearing_pairs).length,
    states_with_margin_pairs: members.filter(state => state.pair_counts.margin_equal_removal).length,
    classes, pair_counts: pairCounts, sampler_mass: totalMass,
    sampler_class_mass: weightedClasses, normalized_class_mass: Object.fromEntries(
      classNames.map(key => [key, totalMass ? weightedClasses[key] / totalMass : 0])),
    sampler_pair_mass: weightedPairs, normalized_pair_mass: Object.fromEntries(
      pairNames.map(key => [key, totalMass ? weightedPairs[key] / totalMass : 0])) };
}
const report = {
  complete: true, score: null, source_dataset: relative(process.cwd(), root),
  methodology: {
    classification: 'Exclusive state classes; mixed retains cardinality, feasibility, geometry or margin mixtures. No audit outcome is changed.',
    coverage_bearing: 'A preferred-vs-other pair with equal triangle removal and either an audited feasibility difference or strictly different teacher margins. Geometry-only negatives excluded.',
    margin: 'Exact native endpoint-v2 max(source/audit, adjacent/audit, source/search, adjacent/search error divided by limit; source and adjacent audit changed_area/0.5). This recipe uses max_changed_area=0.5.',
    sampling: 'category uniform -> parent uniform -> nonempty progress bin uniform -> informative state uniform; rank-loss-v2 pairs normalized within state.',
    limitations: 'Positive coverage-bearing labels are not proof of generalization, batch value or eventual LOD quality. Cardinality-only preferences are valid immediate rewards but provide no distinction between same-removal safe actions.',
  },
  feature_checks: { rows: totalRows, duplicate_feature78_vs23_violations: duplicateFeatureViolations,
    initializer_first_layer_uv_column79_all_zero: initializerColumn79Checked,
    directed_unique_preference_pairs_ignoring_uv79: featurePairs.size,
    reversed_exact_feature_preference_pairs_ignoring_uv79: conflictingPairs,
    interpretation: 'No exact reversed pair does not rule out approximate feature aliasing or UV interference.' },
  raw_gltf_diagnostic_topology: diagnosticTopology,
  total: summarize(states),
  by_uv: Object.fromEntries([0, 1].map(uv => [uv, summarize(states.filter(state => state.uv === uv))])),
  by_category_uv: Object.fromEntries([...categories.keys()].flatMap(category => [0, 1].map(uv =>
    [category + '-uv' + uv, summarize(states.filter(state => state.category === category && state.uv === uv))]))),
  by_dataset: Object.fromEntries([...new Set(states.map(state => state.dataset))].map(dataset =>
    [dataset, summarize(states.filter(state => state.dataset === dataset))])),
  sources,
};
assert(Math.abs(report.total.sampler_mass - 1) < 1e-12);
writeFileSync(output + '/report.json', JSON.stringify(report, null, 2) + '\n');
writeFileSync(output + '/states.json', JSON.stringify(states, null, 2) + '\n');
console.log(JSON.stringify(report.total, null, 2));

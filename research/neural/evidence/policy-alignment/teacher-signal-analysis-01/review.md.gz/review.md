# Independent local ranking review

Read-only production-code review plus CPU artifact analysis. No GPU jobs, network
requests, training, remote actions, or production edits were made by this review.
Run `node runs/neural/teacher-signal-analysis-01/analyze.mjs` to reproduce the
machine-readable report and per-state classifications. `report.json` contains
SHA256 identities for every consumed raw artifact, contract, initializer and
diagnostic glTF/buffer. These are development diagnostics, with no SCORE.

## Established findings

1. `src/chain.cpp:530` builds neural slots output-major, then origin. With
   automatic output, both origins, beam width 1 and budget 2, a reduced predecessor
   enables four slots. The first two have the same output mode. LOD2 therefore
   tests only Reuse and LOD3 only Rebuild in the existing four-level recipe.
   The observed action traces match this schedule. The looser final pixel gate
   gets no endpoint-reuse attempt. This can block a useful final reduction;
   it does not explain the first-LOD Reuse regression.

2. The 715 informative states contain only 292 states with a coverage-bearing
   equal-removal pair, of which 110 contain an audited margin comparison.
   416 states are entirely cardinality comparisons: all candidates pass and
   have precisely equal teacher margins, with preference only for removal of
   two triangles over one. Their exact sampler probability is 38.42%, rather
   than the 58.18% suggested by raw state counts. Cardinality pairs carry 43.97%
   of the normalized pair objective. See `report.json` for exclusive state
   classes and pair classes; mixed states remain explicit.

3. Cardinality dominates the two categories used in the small diagnostic:
   manufactured 96.27% UV-on / 97.85% UV-off pair mass; rock 81.54% / 75.83%.
   The full original moon rock has zero geometric boundary edges and zero
   nonmanifold edges (3,304 faces, 4,956 edges). Its legal topology-preserving
   endpoint actions all remove two incident faces. Two-versus-one teaching
   therefore provides no ordering signal among these actions. This is a
   concrete source of weak supervision on the failing independent rock.

4. Native and teacher feature construction use the same GPU kernel. Resident
   packing stores continuous features as FP32 and reconstructs exact boolean
   and shared condition values; no FP16 feature-rounding mismatch was found.
   Raw data has zero feature 78/23 duplicate violations. Across 27,090 supervised
   pairs there are zero reversed exact-feature preferences after ignoring
   feature 79, whose initial trunk weights were verified all zero. This rules
   out a simple exact paired UV contradiction in this dataset, but not
   approximate feature aliasing, capacity limits or global-state blindness.

5. The current rank gradient sign, per-state pair denominator, rank-only Adam
   parameter slices, output-row indexing and native descending score order
   are mutually consistent. No additional sign/index corruption was found.

## Smallest CPU scheduler regression

Extend `tests/neural_chain.cpp` using its existing `GenerationHooks` harness.
Use a 3x3 planar grid (8 triangles), four levels, automatic output, hybrid origins,
beam width 1, candidate_budget 2 and zero triangle overhead, all owned by the fixture.
Mock evaluation accepts complete measurements; this tests scheduling, not
visual quality. Record screen size, output, input triangle count and previous
triangle count on every guarded proposal.

Make Rebuild return an unchanged input and Reuse return a source-ID-preserving
prefix with the requested half-parent triangle count. LOD1 must emit 4 triangles
so later hybrid origins are genuinely distinct. Require exactly two proposals
per reduced level, one Reuse and one Rebuild, and triangle counts 8/4/2/1.
The current slot order predicts 8/4/2/2 because final Reuse is never called;
this proposed fixture has not been executed. It would demonstrate an actual
missed opportunity, not merely a preferred loop order.

Cover forced output separately so a single-mode request is not accidentally
forced through both modes. A focused fix should change neural slot priority
only and preserve budgets and classical scheduling. Repeat the existing
initializer/checkpoint diagnostic with identical settings after the repair;
do not compare the new runtime's trained output against an old-runtime baseline.

## What is not yet proven

Preferring an accepted two-face removal over an accepted one-face removal is a
valid immediate efficiency target. The report does not establish it as a wrong
long-horizon label. Such a preference can constrain future geometry/legality or
batch packing differently, but a plane toy that assumes this outcome would not
prove it. The evidence establishes that it is largely trivial supervision for
closed meshes, and that improving this target does not establish chain quality.

The bounded next falsification is a continuation audit on training states,
before another training run. Choose a fixed, recorded subset across parent,
UV mode and density, without using evaluation assets. For each state, compare
up to four existing pool actions: a preferred interior action, an equal-margin
boundary action where available, a different interior action, and a feasibility
negative as a control. Force the first action under the same four native gates;
then give every accepted branch the same frozen initializer and eight further
native audit trials, the same action batch and the same fixed source/previous
references and target. Rank branches by final triangles and retain failures,
ties and consumed work. An eight-trial continuation is a bounded diagnostic,
not an optimal-value teacher.

Report how often the current one-step preference reverses, and distinguish
cardinality-driven, audited-margin-driven and feasibility-driven cases. Use
iteration 0 states from retained exact source/previous snapshots, or replay the
baseline observer and capture exact later states; the existing trajectory log
alone cannot reconstruct every committed intermediate mesh. Do not silently
substitute an approximate reconstructed state.

If preferences frequently reverse, train against the demonstrated runtime
continuation objective or use runtime batch-aligned labels. If they do not,
the next question is global-tail generalization with coverage-bearing data,
not an unproven architecture rewrite. Keep 2-vs-1 support distinct from audited
same-removal support in future data admission and health reports.

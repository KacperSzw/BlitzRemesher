import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import path from 'node:path';
const root = 'runs/neural/teacher-optimization-06';
const dir = `${root}/corrected-quality-local`;
const prior = `${root}/final-quality-local`;
const read = (p) => JSON.parse(fs.readFileSync(p));
const hash = (x) => crypto.createHash('sha256').update(x).digest('hex');
const fileHash = (p) => hash(fs.readFileSync(p));
const timings = ['decode_seconds', 'encode_seconds', 'gpu_audit_seconds', 'gpu_confirmation_seconds', 'inference_seconds', 'reference_audit_seconds'];
function withoutTimingAndBinary(a) {
  const b = structuredClone(a);
  delete b.binary_sha256;
  delete b.seconds;
  for (const row of b.rows) {
    delete row.seconds;
    for (const name of timings) delete row.neural[name];
  }
  return b;
}
const report = read(`${dir}/audit/report.json`);
const oldSummary = read(`${prior}/final-summary.json`);
assert.equal(report.complete, true);
assert.equal(report.score, null);
assert.equal(report.score_eligible, false);
assert.equal(report.quality_proven, false);
const ledger = [], rows = [], equality = [], sourceFiles = [];
const binaries = new Set();
let resources = 0, cancellations = 0, confirmationFailures = 0;
const stopCounts = {};
for (const variant of ['initial', 'final']) {
  const file = `${dir}/audit/${variant}.json`, previousFile = `${prior}/audit/${variant}.json`;
  const a = read(file), b = read(previousFile);
  const captured = report.runs.find(r => r.variant === variant);
  assert.equal(captured.process.success, true);
  assert.equal(captured.output_sha256, fileHash(file));
  assert.deepEqual(captured.audit, a);
  assert.equal(a.complete, true);
  assert.equal(a.rows.length, 4);
  for (const key of ['model_sha256', 'manifest_sha256', 'settings_sha256', 'execution_settings_sha256', 'visual_settings_sha256']) assert.equal(a[key], b[key], `${variant} ${key}`);
  assert.notEqual(a.binary_sha256, b.binary_sha256);
  binaries.add(a.binary_sha256);
  const normalized = JSON.stringify(withoutTimingAndBinary(a));
  assert.equal(normalized, JSON.stringify(withoutTimingAndBinary(b)), `${variant}: non-timing content differs`);
  equality.push({variant, previous_raw_sha256:fileHash(previousFile), corrected_raw_sha256:fileHash(file), canonical_non_timing_sha256:hash(normalized), all_non_timing_values_equal:true, all_lod_payloads_equal:true});
  const keys = new Set();
  for (let i=0;i<a.rows.length;i++) {
    const row=a.rows[i], before=b.rows[i];
    assert.equal(row.lods.length,4);
    const key=`${row.asset}:${row.ranking}`;
    assert(!keys.has(key)); keys.add(key);
    assert(a.expected_assets.some(asset=>asset.id===row.asset && asset.category===row.category));
    assert(['constant','learned'].includes(row.ranking));
    resources+=row.neural.resource_failures;
    cancellations+=row.neural.confirmation_cancelled;
    confirmationFailures+=row.neural.confirmation_failure===null?0:1;
    for (const proposal of row.neural.action_proposals) stopCounts[proposal.stop_reason]=(stopCounts[proposal.stop_reason]??0)+1;
    const perLod=[];
    for (let level=1;level<4;level++) {
      const lod=row.lods[level];
      for (const reference of ['source','adjacent']) {
        const m=lod[reference], limit=reference==='source'?lod.source_limit:lod.transition_limit;
        assert.equal(m.complete,true);assert.equal(m.passed,true);
        assert.equal(m.cancelled,false);assert.equal(m.resource_limited,false);assert.equal(m.nonfinite_error,false);
        for(const metric of ['error_px','coverage_px','coverage_upper_px','changed_area','normal_degrees'])assert.equal(Number.isFinite(m[metric]),true,`${key}/${level}/${reference}/${metric}`);
        assert(m.error_px<=limit);assert(m.changed_area<=row.max_changed_area);
        ledger.push({variant,asset:row.asset,ranking:row.ranking,level,reference,limit,max_changed_area:row.max_changed_area,measurement:m});
      }
      perLod.push({level,triangles:lod.triangles,source_error_px:lod.source.error_px,adjacent_error_px:lod.adjacent.error_px});
    }
    rows.push({variant,asset:row.asset,ranking:row.ranking,triangles:row.lods.map(l=>l.triangles),previous_triangles:before.lods.map(l=>l.triangles),counts_unchanged:true,proposal_stops_unchanged:true,fallback_levels:row.neural.fallback_levels,stop_counts:row.neural.action_proposals.reduce((counts,p)=>(counts[p.stop_reason]=(counts[p.stop_reason]??0)+1,counts),{}),lods:perLod});
  }
}
assert.equal(ledger.length,48);assert.equal(resources,0);assert.equal(cancellations,0);assert.equal(confirmationFailures,0);assert.equal(binaries.size,1);
const binary='build/neural/blitz-neural-diagnostics';
assert.equal(fileHash(binary),[...binaries][0]);
const settings=`${dir}/workspace/research/neural/teacher-capability-quality.json`, manifest=`${dir}/workspace/research/neural/action-diagnostic.json`;
assert.equal(fileHash(settings),oldSummary.matching.settings_sha256);
assert.equal(fileHash(manifest),oldSummary.matching.manifest_sha256);
assert.equal(fileHash('runs/neural/v4-initialization/model.blzn'),oldSummary.matching.initial_model_sha256);
assert.equal(fileHash(`${root}/final-checkpoint/model.blzn`),oldSummary.checkpoint.model_sha256);
for(const f of oldSummary.matching.source_files_verified){assert.equal(fileHash(f.path),f.sha256);sourceFiles.push(f);}
const comparisons=[];
for(const initial of rows.filter(r=>r.variant==='initial')){
 const final=rows.find(r=>r.variant==='final' && r.asset===initial.asset && r.ranking===initial.ranking);
 comparisons.push({asset:initial.asset,ranking:initial.ranking,initial:initial.triangles.slice(1),final:final.triangles.slice(1),final_minus_initial:final.triangles.slice(1).map((v,i)=>v-initial.triangles[i+1])});
}
const summary={version:1,scope:'Local corrected-runtime comparison using the same initializer/final-hour weights, settings, assets and budgets as frozen final-quality-local; two development assets, four LODs, no aggregate score',verified:true,complete:true,score:null,score_eligible:false,quality_proven:false,uncensored:false,timing_authority:'local_shared',training_started:false,corrected_runtime_commit:'39b2de7f11579ae18a0c6105e97f5b5312af9e9f',remote_training_revision:read(`${dir}/context.json`).remote_training_revision,checkpoint:{step:413184,learning_elapsed_ms:3600000,model_sha256:oldSummary.checkpoint.model_sha256},matching:{previous_binary_sha256:oldSummary.matching.binary_sha256,corrected_binary_sha256:[...binaries][0],corrected_binary_verified_at_summary:true,settings_sha256:fileHash(settings),manifest_sha256:fileHash(manifest),initial_model_sha256:oldSummary.matching.initial_model_sha256,source_files_verified:sourceFiles},comparison_contract:{raw_files_byte_equal:false,canonical_json_equal_after_excluding_only:['binary_sha256','seconds','rows[].seconds',...timings.map(name=>`rows[].neural.${name}`)],numeric_comparison:'exact; no tolerance or rounding',lod_payloads_and_counters_included:true},equality,measurements:{checked:ledger.length,complete_passed_finite_within_limits:ledger.length,resource_failures:resources,confirmation_cancellations:cancellations,confirmation_failures:confirmationFailures},stop_counts:stopCounts,rows,initial_to_final:comparisons,measurement_ledger:ledger,limitations:['The corrected runtime preserves this observed small diagnostic; this is not full-corpus equivalence or proof that invalid inputs occurred during training.','Trial-budget stops remain visible; complete does not mean visually exhausted.','Constant ranking uses each checkpoint placement policy; diverging trajectories are not identical per-action placements.','Shared-workstation timings are preserved in raw artifacts and do not establish runtime performance.'],raw_report_sha256:fileHash(`${dir}/audit/report.json`)};
fs.writeFileSync(`${dir}/corrected-summary.json`,JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({verified:true,measurements:48,binary_changed:true,canonical_non_timing_equal:true,comparisons,stop_counts:stopCounts},null,2));

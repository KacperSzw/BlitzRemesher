import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {runTeacherProfile} from '/home/kacper/Projects/BlitzRemesher-neural/scripts/neural/teacher-profile.mjs';
const root='/home/kacper/Projects/BlitzRemesher-neural';
process.chdir(root);
const base='runs/neural/baseline-correctness-v3';
const hash=p=>createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const candidate=path.resolve(base,'candidate-placement-prepare');
fs.copyFileSync('build/neural/blitz-neural-placement-prepare',candidate,fs.constants.COPYFILE_EXCL);
const plan=path.resolve(base,'teacher-plan.json');
const request=JSON.parse(fs.readFileSync(plan));
const old=path.resolve('runs/neural/pre-correctness-validation/blitz-neural-placement-prepare');
if(hash(old)!=='fb13c12fae9bb7ddc56e88ca5aebb659ed75ee8032956057fc79d1f77c8c7298')throw Error('Old candidate changed');
const started=Date.now(),deadline=started+10*60000;
const context={version:1,source_revision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),started_at:new Date(started).toISOString(),deadline:new Date(deadline).toISOString(),candidate:{path:candidate,sha256:hash(candidate)},old_candidate:{path:old,sha256:hash(old)},baseline:{path:path.resolve(base,'blitz-neural-placement-prepare'),sha256:hash(base+'/blitz-neural-placement-prepare')},plan:{path:plan,sha256:hash(plan)},timing_authority:'local_shared',cpu_build_concurrent:true,optimizer_updates:0,environment:{VK_DRIVER_FILES:process.env.VK_DRIVER_FILES,icd_sha256:hash(process.env.VK_DRIVER_FILES),BLITZ_TEARDOWN_TRACE:process.env.BLITZ_TEARDOWN_TRACE,DISPLAY:process.env.DISPLAY??null,WAYLAND_DISPLAY:process.env.WAYLAND_DISPLAY??null}};
const output=base+'/local-abba-context.json';
const save=()=>fs.writeFileSync(output,JSON.stringify(context,null,2)+'\n');
save();
for(const [name,baseline] of [['parity',context.baseline.path],['guard-overhead',old]]){
 const directory=path.resolve(base,'local-'+name);
 const report=await runTeacherProfile({baseline,optimized:candidate,directory,plan,model:path.resolve(request.model),workers:1,gpuMemoryMiB:1024,maxSeconds:60,deadline:Math.min(deadline,Date.now()+5*60000),timingAuthority:'local_shared'});
 context[name]={directory,complete:report.complete,error:report.error??null,measured_speedup:report.measured_speedup,process_speedup:report.process_speedup,rows:report.rows.length};
 save();
 console.log(JSON.stringify({comparison:name,...context[name]}));
}
context.finished_at=new Date().toISOString();save();

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const root=process.cwd();
const {validateTeacherRun}=await import(path.join(root,'scripts/neural/teacher-profile.mjs'));
const read=p=>JSON.parse(fs.readFileSync(p));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const base='runs/neural/baseline-correctness-v3';
const context=read(`${base}/local-abba-context.json`), summary=read(`${base}/local-summary.json`);
for(const v of ['candidate','old_candidate','baseline','plan'])assert.equal(hash(context[v].path),context[v].sha256);
const comparisons=[];
for(const name of ['parity','guard-overhead']){
 const p=`${base}/local-${name}/report.json`, report=read(p);
 assert.equal(hash(p),summary.comparisons[name].report_sha256);
 assert.equal(report.complete,true);assert.equal(report.optimizer_updates,0);assert.equal(report.quality_proven,false);
 assert.deepEqual(report.order,['baseline','optimized','optimized','baseline']);
 let reference;const checked=[];
 for(const row of report.rows){
  assert.equal(row.process.success,true);
  const {outputs}=validateTeacherRun(row.directory,report.requests[row.variant],report.binary_sha256[row.variant]);
  if(reference)assert.deepEqual(outputs,reference);else reference=outputs;
  for(const job of row.result.jobs){
   const d=path.join(row.directory,job.directory),i=read(path.join(d,'index.json'));
   assert.equal(hash(path.join(d,i.path)),i.sha256);assert.equal(hash(path.join(d,'episode.bin')),i.episode_sha256);
   assert.equal(hash(path.join(d,'contract.json')),i.contract_sha256);
   checked.push({directory:path.relative(root,d),actions_sha256:i.sha256,episode_sha256:i.episode_sha256,contract_sha256:i.contract_sha256,trajectory_sha256:hash(path.join(d,'trajectory.json'))});
  }
 }
 comparisons.push({name,report_sha256:hash(p),all_four_outputs_equal:true,checked});
}
const bundle='runs/neural/baseline-correctness-v3-prepared',prepared=read(`${bundle}/prepared.json`);
const archive=path.join(bundle,prepared.archive_name);
assert.equal(hash(archive),prepared.archive_sha256);assert.equal(fs.statSync(archive).size,prepared.archive_bytes);
assert.equal(fs.existsSync(path.join(bundle,'rental.json')),false);
const unpacked=fs.mkdtempSync(path.join(os.tmpdir(),'blitz-v3-input-verification-'));
execFileSync('tar',['-xzf',path.resolve(archive),'-C',unpacked]);
const inputs=read(path.join(unpacked,'inputs.json'));
assert.equal(inputs.revision,prepared.revision);assert.equal(inputs.files.length,prepared.files);
for(const f of inputs.files){const p=path.resolve(unpacked,f.path);assert(p.startsWith(unpacked+'/'));assert.equal(hash(p),f.sha256);assert.equal(fs.statSync(p).size,f.bytes);}
const heads=execFileSync('git',['bundle','list-heads',path.join(unpacked,'source.bundle')],{encoding:'utf8'});
assert.equal(heads.trim(), `${prepared.revision} HEAD`);
assert.equal(prepared.branch, "main");
assert(!inputs.files.some(f=>f.path.includes('baseline-cache')));
fs.copyFileSync(path.join(unpacked,'inputs.json'),`${base}/prepared-inputs.json`);
const xml=fs.readFileSync('/tmp/blitz-correctness-final-ctest.xml','utf8');
for(const attribute of ['tests="53"','failures="0"','disabled="0"','skipped="0"'])assert(xml.includes(attribute));
assert.equal((xml.match(/<testcase\b/g)||[]).length,53);
const result={version:1,verified_at:new Date().toISOString(),source_revision:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),comparisons,bundle:{prepared_sha256:hash(`${bundle}/prepared.json`),archive_sha256:hash(archive),archive_bytes:prepared.archive_bytes,revision:prepared.revision,files_verified:inputs.files.length,source_bundle_heads:heads.trim(),no_baseline_cache:true,no_rental_file:true},ctest:{tests:53,failures:0,skipped:0,xml_sha256:hash('/tmp/blitz-correctness-final-ctest.xml')}};
fs.writeFileSync(`${base}/independent-verification.json`,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({verified:true,comparisons:comparisons.map(c=>({name:c.name,jobs:c.checked.length,all_four_outputs_equal:c.all_four_outputs_equal})),bundle:result.bundle,ctest:result.ctest},null,2));

import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
const base='runs/neural/teacher-optimization-06';
const hour=`${base}/collected/results/teacher-optimization/capability-hour`;
const read=p=>JSON.parse(fs.readFileSync(p));
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const latest=read(`${hour}/latest.json`), analysis=read(`${base}/final-teacher-label-analysis.json`);
assert.equal(hash(`${hour}/latest.json`),analysis.latest_sha256);
assert.deepEqual(latest.datasets,analysis.datasets.map(d=>d.dataset));
let states=0,allFour=0;const preferred={},queried={};
for(const d of analysis.datasets){
 const dir=`${hour}/data/${d.dataset}`,index=read(`${dir}/index.json`),trajectory=read(`${dir}/trajectory.json`);
 assert.equal(hash(`${dir}/index.json`),d.index_sha256);assert.equal(hash(`${dir}/trajectory.json`),d.trajectory_sha256);
 assert.equal(index.complete,true);assert.equal(trajectory.length,index.states);assert.equal(index.asset,d.asset);
 let localFour=0;
 for(const t of trajectory){
  const ids=new Set(t.queries.map(q=>`${q.from}:${q.to}`));
  const winners=new Set(t.preferred.map(q=>`${q.from}:${q.to}`));
  assert.equal(winners.size,t.preferred.length);for(const key of winners)assert(ids.has(key));
  preferred[winners.size]=(preferred[winners.size]??0)+1;queried[ids.size]=(queried[ids.size]??0)+1;
  if(winners.size===4&&ids.size===4)localFour++;
 }
 assert.equal(localFour,d.all_four_preferred);states+=trajectory.length;allFour+=localFour;
}
assert.equal(states,latest.states);assert.equal(states,analysis.summary.states);assert.equal(allFour,analysis.summary.all_four_preferred);
assert.deepEqual(preferred,analysis.summary.preferred_histogram);assert.deepEqual(queried,analysis.summary.queried_histogram);
const history=fs.readFileSync(`${hour}/history.jsonl`,'utf8').trim().split('\n').map(JSON.parse);
const phases=history.filter(r=>r.kind==='phases').map(r=>r.value), teacher=phases.filter(v=>v.phase==='teacher'),training=phases.filter(v=>v.phase==='training');
const sum=(rows,key)=>rows.reduce((s,r)=>s+(r[key]??0),0);
const timing=read(`${base}/final-timing-summary.json`);
assert.equal(teacher.length,timing.teacher_jobs);assert.equal(training.length,timing.training_segments);
assert.equal(sum(teacher,'learner_wait_seconds'),timing.learner_wait_seconds);assert.equal(sum(training,'update_seconds'),timing.update_seconds);
assert.deepEqual(latest.checkpoint_timing,timing.checkpoint_timing);
assert.equal(latest.learning_elapsed_ms/1000,timing.learning_elapsed_seconds);
assert.equal(timing.learner_wait_fraction,timing.learner_wait_seconds/timing.learning_elapsed_seconds);
const result={verified:true,verified_at:new Date().toISOString(),latest_sha256:hash(`${hour}/latest.json`),history_sha256:hash(`${hour}/history.jsonl`),analysis_sha256:hash(`${base}/final-teacher-label-analysis.json`),timing_sha256:hash(`${base}/final-timing-summary.json`),shards:analysis.datasets.length,states,all_four_preferred:allFour,guaranteed_zero_rank_pair_fraction:allFour/states,teacher_jobs:teacher.length,training_segments:training.length,learner_wait_fraction:timing.learner_wait_fraction};
fs.writeFileSync(`${base}/final-analysis-verification.json`,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));

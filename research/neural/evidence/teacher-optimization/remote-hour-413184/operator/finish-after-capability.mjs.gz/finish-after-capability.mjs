// One-rental operator handoff: complete the authorized hour, then collect and
// terminate normally instead of starting the queued additional learning pilots.
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { write } from '/workspace/project/scripts/neural/artifacts.mjs';
import { validateOptimizationCheckpoint } from '/workspace/project/scripts/neural/teacher-optimization.mjs';

const directory = '/workspace/results/teacher-optimization';
const policy = {
  requested_at: Date.now(),
  reason: 'User requested local GPU teacher/model quality verification before further remote training.',
  condition: 'Complete normal-exit capability hour and verified published checkpoint.',
  preserve_running_hour: true,
  deferred: ['additional paired training pilots', 'remote full LOD quality comparison'],
};
write('/workspace/results/local-first-policy.json', policy);
const read = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const deadline = 1790864844783 + 64 * 60000; // Hour start plus four-minute handoff grace.
while (Date.now() < deadline) {
  const report = read(directory + '/report.json');
  if (report.capability?.complete) {
    const hour = report.capability;
    if (hour.report.complete !== true || hour.report.status !== 'duration_complete' ||
        !Number.isFinite(hour.report.learning_elapsed_ms) || hour.report.learning_elapsed_ms < 3600000)
      throw new Error('Capability completion does not establish the requested full hour');
    const run = directory + '/capability-hour';
    const latest = read(run + '/latest.json');
    if (latest.complete !== true || latest.checkpoint !== hour.report.checkpoint ||
        latest.checkpoint_sha256 !== hour.report.checkpoint_sha256 ||
        !Number.isSafeInteger(latest.step) || latest.checkpoint !== 'checkpoints/step-' + latest.step)
      throw new Error('Invalid published checkpoint path');
    const checkpoint = run + '/' + latest.checkpoint;
    const index = read(checkpoint + '/index.json');
    const verification = read(checkpoint + '/verification.json');
    validateOptimizationCheckpoint({
      latest, index, verification,
      checkpointSha256: hash(checkpoint + '/checkpoint.pt'),
      modelSha256: hash(checkpoint + '/model.blzn'),
      verificationSha256: hash(checkpoint + '/verification.json'),
    });
    const supervisors = fs.readdirSync('/proc').filter(p => /^[0-9]+$/.test(p)).filter(p => {
      try {
        const args = fs.readFileSync('/proc/' + p + '/cmdline', 'utf8').split('\0');
        return path.basename(args[0]) === 'node' &&
          ['scripts/neural/teacher-optimization-job.mjs', '/workspace/project/scripts/neural/teacher-optimization-job.mjs'].includes(args[1]) &&
          fs.readlinkSync('/proc/' + p + '/cwd') === '/workspace/project';
      } catch { return false; }
    });
    if (supervisors.length !== 1) throw new Error('Expected exactly one owned experiment supervisor');
    const result = {
      ...policy, at: Date.now(), step: latest.step, learning_elapsed_ms: hour.report.learning_elapsed_ms,
      checkpoint_sha256: index.checkpoint_sha256, model_sha256: index.model_sha256,
      supervisor_pid: Number(supervisors[0]), phase_at_handoff: report.phase,
      action: 'SIGTERM to the experiment supervisor; normal archive/checksum/collection/termination remain active.',
    };
    write('/workspace/results/local-first-handoff.json', result);
    process.kill(result.supervisor_pid, 'SIGTERM');
    console.log(JSON.stringify(result));
    process.exit(0);
  }
  if (fs.existsSync('/workspace/job-finished')) throw new Error('Experiment ended before a complete capability hour');
  await new Promise(resolve => setTimeout(resolve, 500));
}
throw new Error('Completed hour was not observed before the handoff deadline; original watchdog remains active');
